﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CheckOutSystem
{
    /// <summary>
    /// Class to store list of Item and Cost
    /// </summary>
    public class ItemList
    {
        public static Hashtable itemlist = new Hashtable()
    {
        {"Apple",60},
        {"Orange",25}
    };
    }
}
