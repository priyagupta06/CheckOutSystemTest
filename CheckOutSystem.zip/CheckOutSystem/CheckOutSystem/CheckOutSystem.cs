﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;
using System.Collections;

namespace CheckOutSystem
{
    /// <summary>
    /// CheckOutSystem Class - holds business logic for generating total bill amount.
    /// </summary>
    public class CheckOutSystem
    {
       
        // TotalBillAmount Method - Accepts Order ItemList as parameter and returns total bill amount.
        public static int TotalBillAmount(ArrayList OrderItemList)
        {
            int TotalBillAmount = 0;

            foreach (Item item in OrderItemList)
            {
                CheckOutSystem.ValidateItem(item);
                TotalBillAmount += (item.Cost * item.Quantity);
            }

            return TotalBillAmount;
        }


        // ValidateItem Method - Accepts Item as paramter and validate the item for Item Name and Quantity
        public static void ValidateItem(Item item)
        {
            if (!ItemList.itemlist.ContainsKey(item.ItemName))
                throw new Exception("Invalid Item Name. Item - " + item.ItemName + " not present in store");

            if (item.Quantity <= 0)
            {
                throw new Exception("Quantity can't be zero or negative. Quantity is not positive for Item " + item.ItemName);
            }
        }

        static void Main()
        {
            Console.WriteLine("CheckOutSystem");
        }

    }
}



