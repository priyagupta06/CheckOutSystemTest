﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CheckOutSystem
{
    /// <summary>
    /// // Item Class with attributes Quanity, ItemName and Cost
    /// </summary>
    public class Item
    {
        public int Quantity;
        public string ItemName;
        public int Cost;

        // Constructor for Item Class for setting ItemName, Quantity and Cost
        public Item(string ItemName, int Quantity)
        {
            this.ItemName = ItemName;

            if (ItemList.itemlist.ContainsKey(ItemName))
            {
                Cost = (int)ItemList.itemlist[ItemName];
            }
            else
            {
                Cost = 0;
            }

            this.Quantity = Quantity;

        }
    }
}
