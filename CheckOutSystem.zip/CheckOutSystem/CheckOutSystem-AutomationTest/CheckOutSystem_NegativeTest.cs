﻿using System;
using System.Text;
using System.Collections.Generic;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System.Collections;
using CheckOutSystem;

namespace CheckOutSystem_AutomationTest
{
    /// <summary>
    /// Negative Test Cases for Check Out System
    /// </summary>
    [TestClass]
    public class CheckOutSystem_NegativeTest
    {
       
        [TestMethod]
        // NegativeTest1 - with invalid Item Name
        public void TestCheckOutSystemNegativeTest1()
        {
            ArrayList OrderItemList = new ArrayList()
            {
                new Item("Apple",1),
                new Item("Pineapple",2)
            };

            try
            {
                CheckOutSystem.CheckOutSystem.TotalBillAmount(OrderItemList);
            }
            catch (System.Exception e)
            {
                if (e.Message.Contains("Invalid Item Name"))
                    Console.WriteLine("Test - CheckOutSystemNegativeTest1 Passed");
            }
        }

        [TestMethod]
        // NegativeTest2 - with negative Item Quantity
        public void TestCheckOutSystemNegativeTest2()
        {
            ArrayList OrderItemList = new ArrayList()
            {
                new Item("Apple",1),
                new Item("Orange",-2)
            };

            try
            {
                CheckOutSystem.CheckOutSystem.TotalBillAmount(OrderItemList);
            }
            catch (System.Exception e)
            {
                if (e.Message.Contains("Quantity can't be zero or negative"))
                    Console.WriteLine("Test - CheckOutSystemNegativeTest2 Passed");
            }
        }

        [TestMethod]
        // NegativeTest3 - with 0 Apple and 2 Oranges
        public void TestCheckOutSystemNegativeTest3()
        {
            ArrayList OrderItemList = new ArrayList()
            {
                new Item("Apple",0),
                new Item("Orange",2)
            };

            try
            {
                CheckOutSystem.CheckOutSystem.TotalBillAmount(OrderItemList);
            }
            catch (System.Exception e)
            {
                if (e.Message.Contains("Quantity can't be zero or negative"))
                    Console.WriteLine("Test - CheckOutSystemNegativeTest3 Passed");
            }

        }
    }
}
