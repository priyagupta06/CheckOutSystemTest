﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System.Collections;
using CheckOutSystem;

namespace CheckOutSystem_AutomationTest
{
    /// <summary>
    /// Positive Test Cases for Check Out System
    /// </summary>
    [TestClass]
    public class CheckOutSystem_PositiveTest
    {
        [TestMethod]
        // PositiveTest1 - with 1 Apple and 2 Orange
        public void TestCheckOutSystemPositiveTest1()
        {
            ArrayList OrderItemList = new ArrayList()
            {
                new Item("Orange",2),
                new Item("Apple",1)
            };

            int totalbillamount = CheckOutSystem.CheckOutSystem.TotalBillAmount(OrderItemList);
            if (totalbillamount == ((int)ItemList.itemlist["Orange"] * 2) + ((int)ItemList.itemlist["Apple"] * 1))
            {
                Console.WriteLine("Test - CheckOutSystemPositiveTest1 Passed");
            }
        }

        [TestMethod]
        // PositiveTest2 - with 2 Apple
        public void TestCheckOutSystemPositiveTest2()
        {
            ArrayList OrderItemList = new ArrayList()
            {
                new Item("Apple",2)
            };

            int totalbillamount = CheckOutSystem.CheckOutSystem.TotalBillAmount(OrderItemList);
            if (totalbillamount == ((int)ItemList.itemlist["Apple"] * 2))
            {
                Console.WriteLine("Test - CheckOutSystemPositiveTest2 Passed");
            }
        }
    }
}
